from numpy import genfromtxt
import matplotlib.pyplot as plt

# data=genfromtxt('test.csv',delimiter=',', names=['x','rollp', 'pitchp','roll0', 'pitch0','roll1', 'pitch1','roll2', 'pitch2', 'l0','l1','l2'])
# plt.plot(data['x'], data['l0'],color='r', label='Piston 1 length (cm)' )
# plt.legend()
# plt.xlabel('time step')
# plt.show()

data=genfromtxt('test2.csv',delimiter=',', names=['x','y1','y2','y3'])
plt.plot(data['x'], data['y1'],color='r', label='Robot 1 Piston Length (cm) ' )
plt.plot(data['x'], data['y2'],color='b', label='Robot 2 Piston Length (cm) ' )
plt.plot(data['x'], data['y3'],color='m', label='Robot 3 Piston Length (cm) ' )
plt.legend()
plt.xlabel('steps')
plt.ylabel('Length (cm)')
plt.xlim(0, 110000)
#plt.ylim(0, 110000)
plt.show()
